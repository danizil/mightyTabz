# MightyTabs
An extension for managing open browser tabs. A popup window on the side contains a list of user created categories. Clicking a list item results in pinning all irrelevant tabs, thereby creating an ordered working environment, and helps to identify unwanted tabs.

To switch to the mighty of your choice simply press the caption and it will turn red. 

Relevant buttons:
=================
+: Add the current highlighted tabs to the mighty (you can highlight several tabs using ctrl and shift the way you do with     text)

-: Remove ----------"------------

N: New tab in mighty

Mightyless Tabs: Unpins the tabs that are without mighties

Unpin All: Unpins all tabs

Revive After Crash: When chrome crashes, it offers to restore all of the tabs. Mighties are saved, but the tabs in them are                     not so you must press the revive button after restoring all tabs

Happy hoarding!